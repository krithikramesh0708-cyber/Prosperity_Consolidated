"""
IMC Prosperity 4 — Round 3 — MAX PNL STRATEGY v3
=================================================
v1: 136,248 (50k+49k+36k)  — good HP, weak options
v2: 62,696  — broke HP by making EMA too fast
v3: Fix HP back to v1 style, keep options improvements
"""

import json
import math
from datamodel import OrderDepth, TradingState, Order
from typing import Dict, List, Tuple

VEV_STRIKES = [4000, 4500, 5000, 5100, 5200, 5300, 5400, 5500, 6000, 6500]

class Trader:
    market_access_fee = 101

    def run(self, state: TradingState) -> Tuple[Dict[str, List[Order]], int, str]:
        result: Dict[str, List[Order]] = {}
        ts_data = {}
        if state.traderData:
            try:
                ts_data = json.loads(state.traderData)
            except:
                pass

        # Get underlying price
        S = None
        if "VELVETFRUIT_EXTRACT" in state.order_depths:
            od_vf = state.order_depths["VELVETFRUIT_EXTRACT"]
            bb = max(od_vf.buy_orders.keys()) if od_vf.buy_orders else None
            ba = min(od_vf.sell_orders.keys()) if od_vf.sell_orders else None
            if bb and ba:
                S = (bb + ba) / 2.0

        # Sonic's signal
        sonic_signal = 0
        if S is not None:
            sp_5200 = self._get_spread("VEV_5200", state)
            sp_5300 = self._get_spread("VEV_5300", state)
            if sp_5200 is not None and sp_5300 is not None:
                if sp_5200 <= 2 and sp_5300 <= 2:
                    sonic_signal = 1

        # 1. HYDROGEL_PACK
        hp_orders, ts_data = self._trade_hydrogel(state, ts_data)
        if hp_orders:
            result["HYDROGEL_PACK"] = hp_orders

        # 2. VELVETFRUIT_EXTRACT
        ve_orders, ts_data = self._trade_velvet(state, ts_data, sonic_signal)
        if ve_orders:
            result["VELVETFRUIT_EXTRACT"] = ve_orders

        # 3. VEV Options
        if S is not None:
            vev_orders, ts_data = self._trade_vouchers(state, ts_data, S)
            for prod, orders in vev_orders.items():
                if orders:
                    result[prod] = orders

        conversions = 0
        return result, conversions, json.dumps(ts_data)

    def _get_spread(self, product: str, state: TradingState):
        if product not in state.order_depths:
            return None
        od = state.order_depths[product]
        bb = max(od.buy_orders.keys()) if od.buy_orders else None
        ba = min(od.sell_orders.keys()) if od.sell_orders else None
        if bb is not None and ba is not None:
            return ba - bb
        return None

    def _get_vwap_mid(self, od: OrderDepth, levels: int = 3) -> float:
        bids = sorted(od.buy_orders.items(), key=lambda x: x[0], reverse=True)[:levels]
        asks = sorted(od.sell_orders.items(), key=lambda x: x[0])[:levels]
        if not bids or not asks:
            if bids: return float(bids[0][0])
            if asks: return float(asks[0][0])
            return -1.0
        bid_vol = sum(v for p, v in bids)
        ask_vol = sum(abs(v) for p, v in asks)
        if bid_vol == 0 or ask_vol == 0:
            return (bids[0][0] + asks[0][0]) / 2.0
        vwap_bid = sum(p * v for p, v in bids) / bid_vol
        vwap_ask = sum(p * abs(v) for p, v in asks) / ask_vol
        return (vwap_bid + vwap_ask) / 2.0

    # ═══════════════════════════════════════════════════════════════════
    # HYDROGEL_PACK — v1 logic that got 50k/day (proven)
    # ═══════════════════════════════════════════════════════════════════

    def _trade_hydrogel(self, state: TradingState, ts_data: dict):
        product = "HYDROGEL_PACK"
        if product not in state.order_depths:
            return [], ts_data

        od = state.order_depths[product]
        position = state.position.get(product, 0)
        limit = 200
        orders = []

        best_bid = max(od.buy_orders.keys()) if od.buy_orders else None
        best_ask = min(od.sell_orders.keys()) if od.sell_orders else None
        if best_bid is None and best_ask is None:
            return [], ts_data

        mid = self._get_vwap_mid(od, 3)
        if mid < 0:
            mid = (best_bid + best_ask) / 2.0 if (best_bid and best_ask) else 10000.0

        # Slow EMA — this is the key: don't overreact
        if "hp_ema" not in ts_data:
            ts_data["hp_ema"] = mid
        ts_data["hp_ema"] = 0.05 * mid + 0.95 * ts_data["hp_ema"]

        # Fair = blend of EMA + mild anchor to 10000
        fair = 0.45 * mid + 0.45 * ts_data["hp_ema"] + 0.1 * 10000.0

        buy_room = limit - position
        sell_room = limit + position

        # Aggressive taking — tight threshold
        if od.sell_orders and buy_room > 0:
            for p in sorted(od.sell_orders.keys()):
                if p < fair - 0.5 and buy_room > 0:
                    qty = min(-od.sell_orders[p], buy_room)
                    orders.append(Order(product, p, qty))
                    buy_room -= qty
                    position += qty
                else:
                    break

        if od.buy_orders and sell_room > 0:
            for p in sorted(od.buy_orders.keys(), reverse=True):
                if p > fair + 0.5 and sell_room > 0:
                    qty = min(od.buy_orders[p], sell_room)
                    orders.append(Order(product, p, -qty))
                    sell_room -= qty
                    position -= qty
                else:
                    break

        # Position-skewed quoting
        skew = -(position / limit) * 6.0
        quoted_fair = fair + skew
        h_spread = 2 if abs(position / limit) < 0.5 else 3

        bid_p = int(round(quoted_fair - h_spread))
        ask_p = int(round(quoted_fair + h_spread))

        if best_bid is not None:
            bid_p = min(bid_p, best_bid + 1)
        if best_ask is not None:
            ask_p = max(ask_p, best_ask - 1)

        if bid_p >= ask_p:
            m = int(mid)
            bid_p, ask_p = m - 1, m + 1

        if buy_room > 0:
            orders.append(Order(product, bid_p, buy_room))
        if sell_room > 0:
            orders.append(Order(product, ask_p, -sell_room))

        return orders, ts_data

    # ═══════════════════════════════════════════════════════════════════
    # VELVETFRUIT_EXTRACT — Eigen Drift + Sonic Signal
    # ═══════════════════════════════════════════════════════════════════

    def _trade_velvet(self, state: TradingState, ts_data: dict, sonic_signal: int):
        product = "VELVETFRUIT_EXTRACT"
        if product not in state.order_depths:
            return [], ts_data

        od = state.order_depths[product]
        position = state.position.get(product, 0)
        timestamp = state.timestamp
        limit = 200
        orders = []

        best_bid = max(od.buy_orders.keys()) if od.buy_orders else None
        best_ask = min(od.sell_orders.keys()) if od.sell_orders else None
        if not best_bid or not best_ask:
            return [], ts_data

        mid = (best_bid + best_ask) / 2.0

        # Fast EMA tracking (proven to work best for VFE)
        if "vf_ema" not in ts_data:
            ts_data["vf_ema"] = mid
        ts_data["vf_ema"] = 0.3 * mid + 0.7 * ts_data["vf_ema"]

        fair = ts_data["vf_ema"]

        # Eigen imbalance
        bids = sorted(od.buy_orders.items(), key=lambda x: x[0], reverse=True)
        asks = sorted(od.sell_orders.items(), key=lambda x: x[0])

        b1 = bids[0][1] if len(bids) > 0 else 0
        a1 = abs(asks[0][1]) if len(asks) > 0 else 0
        b2 = bids[1][1] if len(bids) > 1 else 0
        a2 = abs(asks[1][1]) if len(asks) > 1 else 0
        b3 = bids[2][1] if len(bids) > 2 else 0
        a3 = abs(asks[2][1]) if len(asks) > 2 else 0

        eigen_buy = b1 + 0.45 * b2 + 0.2 * b3
        eigen_sell = a1 + 0.45 * a2 + 0.2 * a3
        total = eigen_buy + eigen_sell
        imb = (eigen_buy - eigen_sell) / total if total > 0 else 0
        fair += imb * 1.5

        # Sonic signal: tight VEV spreads = buy VFE
        if sonic_signal > 0:
            fair += 0.3

        buy_room = limit - position
        sell_room = limit + position

        # Take mispriced orders
        if buy_room > 0:
            remaining = buy_room
            for ask_price in sorted(od.sell_orders.keys()):
                if ask_price < fair - 0.5 and remaining > 0:
                    take_qty = min(-od.sell_orders[ask_price], remaining)
                    orders.append(Order(product, ask_price, take_qty))
                    remaining -= take_qty
                    position += take_qty
                else:
                    break
            buy_room = remaining

        if sell_room > 0:
            remaining = sell_room
            for bid_price in sorted(od.buy_orders.keys(), reverse=True):
                if bid_price > fair + 0.5 and remaining > 0:
                    take_qty = min(od.buy_orders[bid_price], remaining)
                    orders.append(Order(product, bid_price, -take_qty))
                    remaining -= take_qty
                    position -= take_qty
                else:
                    break
            sell_room = remaining

        # MM quotes
        skew = -(position / limit) * 2.0
        quoted_fair = fair + skew

        bid_p = min(int(round(quoted_fair - 1)), best_bid + 1)
        ask_p = max(int(round(quoted_fair + 1)), best_ask - 1)

        if bid_p >= ask_p:
            bid_p, ask_p = int(mid) - 1, int(mid) + 1

        if buy_room > 0:
            orders.append(Order(product, bid_p, buy_room))
        if sell_room > 0:
            orders.append(Order(product, ask_p, -sell_room))

        return orders, ts_data

    # ═══════════════════════════════════════════════════════════════════
    # BS helpers
    # ═══════════════════════════════════════════════════════════════════

    def _norm_cdf(self, x: float) -> float:
        return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))

    def _bs_call_v(self, S: float, K: float, v: float) -> float:
        if v <= 0:
            return max(0.0, S - K)
        try:
            d1 = (math.log(S / K) + 0.5 * v**2) / v
            d2 = d1 - v
            return S * self._norm_cdf(d1) - K * self._norm_cdf(d2)
        except:
            return max(0.0, S - K)

    # ═══════════════════════════════════════════════════════════════════
    # VEV Options — Calibrated BS + Aggressive MM
    # ═══════════════════════════════════════════════════════════════════

    def _trade_vouchers(self, state: TradingState, ts_data: dict, S: float):
        orders_by_product = {}
        limit = 300

        # Calibrate implied_v from ATM
        implied_v = None
        for calib_k in [5200, 5300, 5100]:
            prod = f"VEV_{calib_k}"
            if prod not in state.order_depths:
                continue
            od = state.order_depths[prod]
            bb = max(od.buy_orders.keys()) if od.buy_orders else None
            ba = min(od.sell_orders.keys()) if od.sell_orders else None
            if bb is None or ba is None:
                continue
            C_market = (bb + ba) / 2.0
            intrinsic = max(0.0, S - calib_k)
            if C_market > intrinsic + 1.0:
                low, high = 1e-5, 0.5
                for _ in range(25):
                    mid_v = (low + high) / 2.0
                    p = self._bs_call_v(S, calib_k, mid_v)
                    if p > C_market:
                        high = mid_v
                    else:
                        low = mid_v
                implied_v = mid_v
                break

        if implied_v is None:
            implied_v = 0.034

        # Smooth the IV to avoid jerky fair values
        if "opt_iv" not in ts_data:
            ts_data["opt_iv"] = implied_v
        ts_data["opt_iv"] = 0.4 * implied_v + 0.6 * ts_data["opt_iv"]
        sv = ts_data["opt_iv"]

        for k in VEV_STRIKES:
            product = f"VEV_{k}"
            if product not in state.order_depths:
                continue

            od = state.order_depths[product]
            position = state.position.get(product, 0)
            orders = []

            best_bid = max(od.buy_orders.keys()) if od.buy_orders else None
            best_ask = min(od.sell_orders.keys()) if od.sell_orders else None

            if best_bid is None or best_ask is None:
                orders_by_product[product] = orders
                continue

            market_mid = (best_bid + best_ask) / 2.0
            market_spread = best_ask - best_bid
            intrinsic = max(0.0, S - k)

            # Skip deep OTM
            if k in {6000, 6500}:
                orders_by_product[product] = orders
                continue

            # Deep ITM: only take mispricing vs intrinsic
            if k in {4000, 4500}:
                fair = intrinsic
                edge = market_spread * 0.3
                buy_room = limit - position
                sell_room = limit + position
                if best_ask < fair - edge and buy_room > 0:
                    for ap in sorted(od.sell_orders.keys()):
                        if ap < fair - edge and buy_room > 0:
                            qty = min(-od.sell_orders[ap], buy_room)
                            orders.append(Order(product, ap, qty))
                            buy_room -= qty
                        else:
                            break
                if best_bid > fair + edge and sell_room > 0:
                    for bp in sorted(od.buy_orders.keys(), reverse=True):
                        if bp > fair + edge and sell_room > 0:
                            qty = min(od.buy_orders[bp], sell_room)
                            orders.append(Order(product, bp, -qty))
                            sell_room -= qty
                        else:
                            break
                orders_by_product[product] = orders
                continue

            # Tradeable strikes: 5000-5500
            fair = self._bs_call_v(S, k, sv)
            fair = max(fair, intrinsic + 0.1)

            buy_room = limit - position
            sell_room = limit + position

            # Take threshold
            take_edge = 0.5

            if od.sell_orders and buy_room > 0:
                for ap in sorted(od.sell_orders.keys()):
                    if ap < fair - take_edge and buy_room > 0:
                        qty = min(-od.sell_orders[ap], buy_room)
                        orders.append(Order(product, ap, qty))
                        buy_room -= qty
                        position += qty
                    else:
                        break

            if od.buy_orders and sell_room > 0:
                for bp in sorted(od.buy_orders.keys(), reverse=True):
                    if bp > fair + take_edge and sell_room > 0:
                        qty = min(od.buy_orders[bp], sell_room)
                        orders.append(Order(product, bp, -qty))
                        sell_room -= qty
                        position -= qty
                    else:
                        break

            # MM quoting
            skew = -(position / limit) * 1.5
            quoted_fair = fair + skew

            if k in {5300, 5400, 5500, 5200}:
                h_spread = 1
            else:
                h_spread = 2

            bid_p = int(round(quoted_fair - h_spread))
            ask_p = int(round(quoted_fair + h_spread))

            bid_p = min(bid_p, best_bid + 1)
            ask_p = max(ask_p, best_ask - 1)

            if bid_p >= ask_p:
                bid_p = int(market_mid) - 1
                ask_p = int(market_mid) + 1
            if bid_p < 0:
                bid_p = 0
            if ask_p <= bid_p:
                ask_p = bid_p + 1

            buy_room = limit - position
            sell_room = limit + position

            if buy_room > 0:
                orders.append(Order(product, bid_p, buy_room))
            if sell_room > 0:
                orders.append(Order(product, ask_p, -sell_room))

            orders_by_product[product] = orders

        return orders_by_product, ts_data