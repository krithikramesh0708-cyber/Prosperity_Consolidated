import json
import math
from datamodel import OrderDepth, TradingState, Order, Trade
from typing import Dict, List, Tuple

# --- Configuration & constants ---
LIMITS = {
    'VELVETFRUIT_EXTRACT': 200, 'HYDROGEL_PACK': 200,
    'VEV_4000': 300, 'VEV_4500': 300, 'VEV_5000': 300, 'VEV_5100': 300,
    'VEV_5200': 300, 'VEV_5300': 300, 'VEV_5400': 300, 'VEV_5500': 300,
    'VEV_6000': 300, 'VEV_6500': 300
}

STRIKE_MAP = {
    'VEV_4000': 4000, 'VEV_4500': 4500, 'VEV_5000': 5000, 'VEV_5100': 5100,
    'VEV_5200': 5200, 'VEV_5300': 5300, 'VEV_5400': 5400, 'VEV_5500': 5500,
    'VEV_6000': 6000, 'VEV_6500': 6500
}

SMILE_A, SMILE_B, SMILE_C = -0.01839205, -0.00707253, 0.27569916
DAYS_PER_YEAR = 365.0
TTE_START = 4.0

class Trader:
    def __init__(self):
        self.ema = {}
        self.mark14_signals = {}
        self.alpha_mark = 0.1
        
    def run(self, state: TradingState):
        d = json.loads(state.traderData) if state.traderData else {}
        tc = d.get('tc', 0); d['tc'] = tc + 1
        day_in_sim = tc // 10000
        tick_in_day = tc % 10000
        TTE = max(0.0001, (TTE_START - day_in_sim - tick_in_day / 10000.0) / DAYS_PER_YEAR)
        
        # 1. Update Oracle Signals (Mark 14)
        for p, trades in state.market_trades.items():
            s = self.mark14_signals.get(p, 0.0)
            for t in trades:
                if t.buyer == 'Mark 14': s = 0.8 * s + 0.2 * 1.0
                if t.seller == 'Mark 14': s = 0.8 * s - 0.2 * 1.0
            self.mark14_signals[p] = s

        # 2. Market State
        books = {}
        for p, od in state.order_depths.items():
            b, a = sorted(od.buy_orders.items(), reverse=True), sorted(od.sell_orders.items())
            if b and a: 
                mid = (b[0][0]+a[0][0])/2.0
                books[p] = {'bid': b[0][0], 'ask': a[0][0], 'mid': mid, 'bids': b, 'asks': a, 'spread': a[0][0]-b[0][0]}
                self.ema[p] = 0.95 * self.ema.get(p, mid) + 0.05 * mid

        result = {}
        net_delta = 0.0
        S = books['VELVETFRUIT_EXTRACT']['mid'] if 'VELVETFRUIT_EXTRACT' in books else None

        # 3. Execution Phase
        for p in state.order_depths:
            if p not in books: continue
            pos = state.position.get(p, 0)
            limit = LIMITS.get(p, 300)
            
            # Fair Value
            if p in STRIKE_MAP and S:
                iv = self.get_iv(S, STRIKE_MAP[p], TTE)
                theo, delta = self.bs_call(S, STRIKE_MAP[p], TTE, iv)
                fair = theo
            else:
                fair = self.ema.get(p, books[p]['mid'])
                
            # Bias from Mark 14
            lean = self.mark14_signals.get(p, 0.0)
            fair += (lean * 0.5) if p in STRIKE_MAP else (lean * 10.0)
            
            # Delta Hedge Extractor
            if p == 'VELVETFRUIT_EXTRACT':
                fair -= net_delta * 4.0
            
            # Orders
            orders = []
            f = fair - 8.0 * (pos/limit)**3 # Cubic skew for position protection
            
            # Taker
            edge = 0.5 if p in STRIKE_MAP else 1.0
            for ap, av in books[p]['asks']:
                if ap <= fair - edge and pos < limit:
                    q = min(-av, limit - pos); orders.append(Order(p, ap, q)); pos += q
            for bp, bv in books[p]['bids']:
                if bp >= fair + edge and pos > -limit:
                    q = min(bv, limit + pos); orders.append(Order(p, bp, -q)); pos -= q
            
            # Maker
            spread = 1 if p in STRIKE_MAP else 3
            b_p = min(int(math.floor(f - spread)), books[p]['bid'] + 1)
            s_p = max(int(math.ceil(f + spread)), books[p]['ask'] - 1)
            if limit - pos > 0: orders.append(Order(p, b_p, limit - pos))
            if limit + pos > 0: orders.append(Order(p, s_p, -(limit + pos)))
            
            result[p] = orders
            if p in STRIKE_MAP and S:
                _, delta = self.bs_call(S, STRIKE_MAP[p], TTE, iv)
                net_delta += (pos * delta * 0.1)

        return result, 0, json.dumps(d)

    def get_iv(self, S, K, TTE):
        m = math.log(K/S) / math.sqrt(max(1e-9, TTE))
        return max(0.01, SMILE_A * m**2 + SMILE_B * m + SMILE_C)

    def bs_call(self, S, K, TTE, sigma):
        if TTE <= 1e-8 or sigma <= 1e-8: return max(S - K, 0), 1.0 if S > K else 0.0
        d1 = (math.log(S/K) + 0.5 * sigma**2 * TTE) / (sigma * math.sqrt(TTE))
        d2 = d1 - sigma * math.sqrt(TTE)
        return S * _phi(d1) - K * _phi(d2), _phi(d1)

def _phi(x):
    a1, a2, a3, a4, a5 = 0.254829592, -0.284496736, 1.421413741, -1.453152027, 1.061405429
    p = 0.3275911; sign = 1 if x >= 0 else -1; x = abs(x); t = 1.0 / (1.0 + p * x)
    y = 1.0 - (((((a5*t + a4)*t) + a3)*t + a2)*t + a1)*t * math.exp(-x*x/2.0)
    return 0.5 * (1.0 + sign * y)